const mongoose = require("mongoose");

const connectDB = async () => {
  try {
    const uri = process.env.MONGODB_URI;

    console.log(
      "MongoDB URI format valid:",
      typeof uri === "string" &&
      (uri.startsWith("mongodb://") ||
       uri.startsWith("mongodb+srv://"))
    );

    if (
      typeof uri !== "string" ||
      !(uri.startsWith("mongodb://") ||
        uri.startsWith("mongodb+srv://"))
    ) {
      throw new Error("Check MONGODB_URI in your .env file");
    }

    await mongoose.connect(uri);

    console.log("MongoDB connected successfully");
  } catch (error) {
    console.error("MongoDB connection failed:", error.message);
    process.exit(1);
  }
};

module.exports = connectDB;