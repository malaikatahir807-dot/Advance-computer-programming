
const express = require("express");
const controller = require("./category.controller");

const router = express.Router();

router.post("/", controller.createCategory);
router.get("/", controller.getCategories);

module.exports = router;
