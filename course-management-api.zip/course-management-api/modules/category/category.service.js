
const Category = require("./category.model");

const createCategory = async (data) => {
  if (!data.name || !data.name.trim()) {
    const error = new Error("Category name is required");
    error.statusCode = 400;
    throw error;
  }

  return Category.create({
    name: data.name,
    description: data.description || ""
  });
};

const getCategories = async () => {
  return Category.find().sort({ createdAt: -1 });
};

module.exports = { createCategory, getCategories };
