
const categoryService = require("./category.service");

const createCategory = async (req, res, next) => {
  try {
    const category = await categoryService.createCategory(req.body);
    res.status(201).json({
      message: "Category created successfully",
      category
    });
  } catch (error) {
    if (error.code === 11000) {
      error.statusCode = 409;
      error.message = "Category already exists";
    }
    next(error);
  }
};

const getCategories = async (req, res, next) => {
  try {
    const categories = await categoryService.getCategories();
    res.status(200).json({ categories });
  } catch (error) {
    next(error);
  }
};

module.exports = { createCategory, getCategories };
