
const authService = require("./auth.service");

const register = async (req, res, next) => {
  try {
    const result = await authService.register(
      req.body.name,
      req.body.email,
      req.body.password
    );

    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
};

const login = async (req, res, next) => {
  try {
    const result = await authService.login(
      req.body.email,
      req.body.password
    );

    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
};

module.exports = { register, login };
